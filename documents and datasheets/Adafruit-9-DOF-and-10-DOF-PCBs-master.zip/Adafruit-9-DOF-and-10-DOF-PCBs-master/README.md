Adafruit-9-DOF-and-10-DOF-PCBs
==============================

This is the PCB for the Adafruit 9-DOF and 10-DOF Breakout boards
Format is EagleCAD schematic and board layout

For more details, check out the product pages at

-----> https://www.adafruit.com/product/1714
-----> https://www.adafruit.com/product/1604


Adafruit invests time and resources providing this open source design, 
please support Adafruit and open-source hardware by purchasing 
products from Adafruit!

Designed by Adafruit Industries.  
Creative Commons Attribution, Share-Alike license, check license.txt for more information
All text above must be included in any redistribution